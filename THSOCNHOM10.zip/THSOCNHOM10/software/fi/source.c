#include <stdio.h>
#include "system.h"
#include "sys/alt_irq.h"
#include <stdint.h>
#include <io.h>
#define RESULT_READ_DELAY 1
#define SW_0_BASE 0x41210
int result_matrix[7][7];


volatile uint8_t *Matrix_data = (volatile uint8_t *)(CONVOLUTION_0_BASE + 0x00);
volatile uint8_t *Kernel_data = (volatile uint8_t *)(CONVOLUTION_0_BASE + 0x04);
volatile uint32_t *Result = (volatile uint32_t *)(CONVOLUTION_0_BASE + 0x08);

//horizonal
const int kernel_1[3][3] = {
    {1, 0, -1},
    {1, 0, -1},
    {1, 0, -1}
};
//vertical
const int kernel_2[3][3] = {
    {1, 1, 1},
    {0, 0, 0},
    {-1, -1, -1}
};
//Diagonal Edge Enhancer
const int kernel_3[3][3] = {
    {1,  0,  0},
    {0, 1,  1},
    {1,  0,  1}
};

//identity
const int kernel_4[3][3] = {
    {0, 0, 0},
    {0, 1, 0},
    {0, 0, 0}
};
//sobel_x
const int kernel_5[3][3] = {
    {-1, 0, 1},
    {-2, 0, 2},
    {-1, 0, 1}
};
//sobel_y
const int kernel_6[3][3] = {
    {-1, -2, -1},
    {0,  0,  0},
    {1,  2,  1}
};
//_sharpen
const int kernel_7[3][3] = {
    { 0, -1,  0},
    {-1,  5, -1},
    { 0, -1,  0}
};
//gaussian
const int kernel_8[3][3] = {
    {1, 2, 1},
    {2, 4, 2},
    {1, 2, 1}
};
//box_blur
const int kernel_9[3][3] = {
    {1, 1, 1},
    {1, 1, 1},
    {1, 1, 1}
};
//edge_enhance
const int kernel_10[3][3] = {
    {0,  0,  0},
    {-1, 1,  0},
    {0,  0,  0}
};
//diag_45
const int kernel_11[3][3] = {
    {0,  1,  0},
    {-1,  0,  1},
    {0, -1,  0}
};
//diag_135
const int kernel_12[3][3] = {
    {1,  0, -1},
    {0,  0,  0},
    {-1,  0,  1}
};
//laplacian
const int kernel_13[3][3] = {
    {0,  1,  0},
    {1, -4,  1},
    {0,  1,  0}
};
//emboss
const int kernel_14[3][3] = {
    {-2, -1,  0},
    {-1,  1,  1},
    {0,  1,  2}
};
//top_sobel
const int kernel_15[3][3] = {
    {-1, -1, -1},
    { 0,  0,  0},
    { 1,  1,  1}
};


void select_kernel(int kernel_id) {
    const int (*kernel)[3];

    switch (kernel_id) {
        case 0:
            kernel = kernel_1;
            break;
        case 1:
            kernel = kernel_2;
            break;
        case 2:
            kernel = kernel_3;
            break;
        case 3:
            kernel = kernel_4;
            break;
        case 4:
            kernel = kernel_5;
            break;
        case 5:
            kernel = kernel_6;
            break;
        case 6:
            kernel = kernel_7;
            break;
        case 7:
            kernel = kernel_8;
            break;
        case 8:
            kernel = kernel_9;
            break;
        case 9:
            kernel = kernel_10;
            break;
        case 10:
            kernel = kernel_11;
            break;
        case 11:
            kernel = kernel_12;
            break;
        case 12:
            kernel = kernel_13;
            break;
        case 13:
            kernel = kernel_14;
            break;
        case 14:
            kernel = kernel_15;
            break;
        default:
            kernel = kernel_1; // Kernel mặc định
            break;
    }

    // Ghi kernel vào thanh ghi Kernel_data theo dạng 2 chiều
    for (int row = 0; row < 3; row++) {
        for (int col = 0; col < 3; col++) {
            *Kernel_data = kernel[row][col];
        }
    }
}


void delay_ns(int ns) {
    for (volatile int i = 0; i < ns ; i++) {
        // No operation, chỉ để tạo trễ
    }
}

void write_matrix(const int matrix[9][9]) {
    for (int row = 0; row < 9; row++) {
        for (int col = 0; col < 9; col++) {
            *Matrix_data = matrix[row][col];
        }
    }
    delay_ns(96); // đợi ghi vào buff

}



int convert_data(int raw_data) {
    // Lấy giá trị dữ liệu (24 bit)
    int sign_bit = (raw_data >> 23) & 0x1; // Bit dấu nằm ở vị trí 23
    int data;

    if (sign_bit) {
        // Nếu là số âm: đảo bit và cộng 1
        data = ~raw_data & 0xFFFFFF ; // Đảo bit trên 24 bit
        data = data + 1;
        data = -data;                // Chuyển sang số âm
    } else {
        // Nếu là số dương: giữ nguyên
        data = raw_data & 0xFFFFFF; // Chỉ lấy 24 bit dưới
    }

    return data;
}

void read_results() {
    for (int i = 0; i < 49; i++) {
    	 //usleep(50000000);
//    	 for (int j = 0; j < 1000000; j++){
//
//    	 }
        // Đọc kết quả từ thanh ghi
        int result = IORD(CONVOLUTION_0_BASE,i);

        // Tách dòng, cột và dữ liệu
        int row = (result >> 0) & 0xF;   // 4 bit đầu: dòng
        IOWR(HEX_4_BASE, 0, row);
        int col = (result >> 4) & 0xF;     // 4 bit tiếp theo: cột
        IOWR(HEX_5_BASE, 0, col);

        int hex0 = (result >> 8) & 0xF;    // 4 bit đầu
        int hex1 = (result >> 12) & 0xF;    // 4 bit tiếp theo
        int hex2 = (result >> 16) & 0xF;    // 4 bit tiếp theo
        int hex3 = (result >> 20) & 0xF;   // 4 bit tiếp theo

            // Hiển thị giá trị kết quả lên 4 LED HEX
        IOWR(HEX_0_BASE, 0, hex0); // HEX0 hiển thị 4 bit đầu
        IOWR(HEX_1_BASE, 0, hex1); // HEX1 hiển thị 4 bit tiếp theo
        IOWR(HEX_2_BASE, 0, hex2); // HEX2 hiển thị 4 bit tiếp theo
        IOWR(HEX_3_BASE, 0, hex3); // HEX3 hiển thị 4 bit tiếp theo

        int raw_data = (result >> 8) & 0xFFFFFF;     // 24 bit: dữ liệu thô

        // Chuyển đổi dữ liệu thô thành giá trị có dấu
        int data = convert_data(raw_data);

        // Lưu dữ liệu vào ma trận kết quả

            result_matrix[row][col] = data;
            printf("Result %d(decimal): %d (%d, %d) (data: 0x%04X)\n", i, result, col, row, data);

    }
}


int main() {
    // Đọc giá trị từ switch (SW[1:0] để chọn kernel)
    int switch_value = IORD_16DIRECT(SW_0_BASE, 0); // Lấy 2 bit từ switch

    int selected_kernel = switch_value & 0x3FF;        // Chọn kernel dựa vào switch
    // Chọn kernel và ghi vào thanh ghi kernel
    select_kernel(selected_kernel);
    // Matrix ví dụ 9x9
    const int matrix[9][9] = {
        {25, 12, 41, 33, 8,  59, 76, 3,  67},
        {74, 28, 1,  50, 45, 31, 36, 19, 64},
        {21, 53, 73, 9,  7,  77, 35, 42, 6 },
        {60, 18, 58, 71, 47, 15, 2,  24, 39},
        {4,  20, 43, 70, 32, 13, 40, 68, 29},
        {27, 61, 48, 63, 30, 11, 72, 79, 22},
        {5,  38, 37, 66, 62, 75, 26, 78, 17},
        {80, 10, 14, 44, 23, 16, 34, 49, 46},
        {52, 54, 55, 56, 51, 65, 81, 57, 69}
    };


    // Ghi matrix vào thanh ghi matrix
    write_matrix(matrix);

    // Kích hoạt phép toán
//    *En = 1;

/*Sau khi code lại thì phần này chỉ đọc và hiển thị được phần tử đầu tiên
 * vì muốn đọc nhiều phải cho nó read nhiều lần (49 lần sẽ đc full ma trận ra)
* buff_read trong thiết kế được viết dưới dạng FIFO
  nên sẽ đọc ra theo tương ứng từ (0,0) đầu tiên
*/

    // Đọc kết quả từ phần cứng
        read_results();

        // Hiển thị kết quả ma trận
        printf("Kết quả ma trận 7x7:\n");
           for (int row = 0; row < 7; row++) {
               for (int col = 0; col < 7; col++) {
                   printf("%5d (0x%04X)", result_matrix[row][col], result_matrix[row][col]); // Hiển thị dữ liệu
               }
               printf("\n");
           }
          while(1){
        	  int data;
        	  data = IORD_16DIRECT(SW_0_BASE, 0)& 0x3FF;
        	  int run  = data & 0xF;
          if(run == 15){
        	  int r    = (data>>4) & 0x7;
        	  int c	   = (data>>7) & 0x7;
        	  IOWR(HEX_4_BASE, 0, r);
        	  IOWR(HEX_5_BASE, 0, c);
        	  int hex0 = (result_matrix[r][c]) & 0xF;    // 4 bit đầu
        	  int hex1 = (result_matrix[r][c]>>4) & 0xF;    // 4 bit tiếp theo
        	  int hex2 = (result_matrix[r][c]>>8) & 0xF;    // 4 bit tiếp theo
        	  int hex3 = (result_matrix[r][c]>>12) & 0xF;   // 4 bit tiếp theo
        	  IOWR(HEX_0_BASE, 0, hex0); // HEX0 hiển thị 4 bit đầu
        	  IOWR(HEX_1_BASE, 0, hex1); // HEX1 hiển thị 4 bit tiếp theo
        	  IOWR(HEX_2_BASE, 0, hex2); // HEX2 hiển thị 4 bit tiếp theo
        	  IOWR(HEX_3_BASE, 0, hex3);
          } else {

        	  int r    = 0;
        	  int c	   = 0;
        	  IOWR(HEX_4_BASE, 0, r);
        	  IOWR(HEX_5_BASE, 0, c);
          int hex0 = 0;    // 4 bit đầu
          int hex1 = 0;    // 4 bit tiếp theo
          int hex2 = 0;    // 4 bit tiếp theo
          int hex3 = 0;   // 4 bit tiếp theo
          IOWR(HEX_0_BASE, 0, hex0); // HEX0 hiển thị 4 bit đầu
          IOWR(HEX_1_BASE, 0, hex1); // HEX1 hiển thị 4 bit tiếp theo
          IOWR(HEX_2_BASE, 0, hex2); // HEX2 hiển thị 4 bit tiếp theo
          IOWR(HEX_3_BASE, 0, hex3); // HEX3 hiển thị 4 bit tiếp theo

          }
          }

    return 0;
}

