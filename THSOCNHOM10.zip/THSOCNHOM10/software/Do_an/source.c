/*
 * source.c
 *
 *  Created on: 03-12-2024
 *      Author: ADMIN
 */
#include <stdio.h>
#include "system.h"
#include "sys/alt_irq.h"
#include <stdint.h>
#include <io.h>
#define RESULT_READ_DELAY 1 // Delay 1ns (giả lập)

int result_matrix[7][7];


volatile uint8_t *Matrix_data = (volatile uint8_t *)(CONVOLUTION_0_BASE + 0x00);
volatile uint8_t *Kernel_data = (volatile uint8_t *)(CONVOLUTION_0_BASE + 0x04);
volatile uint32_t *Result = (volatile uint32_t *)(CONVOLUTION_0_BASE + 0x08);


const int kernel_1[3][3] = {
    {1, 0, -1},
    {1, 0, -1},
    {1, 0, -1}
};

const int kernel_2[3][3] = {
    {1, 1, 1},
    {0, 0, 0},
    {-1, -1, -1}
};

const int kernel_3[3][3] = {
    {1,  0,  0},
    {0, 1,  1},
    {1,  0,  1}
};

void select_kernel(int kernel_id) {
    const int (*kernel)[3];

    switch (kernel_id) {
        case 0:
            kernel = kernel_1;
            break;
        case 1:
            kernel = kernel_2;
            break;
        case 2:
            kernel = kernel_3;
            break;
        default:
            kernel = kernel_1; // Kernel mặc định
            break;
    }

    // Ghi kernel vào thanh ghi Kernel_data theo dạng 2 chiều
    for (int row = 0; row < 3; row++) {
        for (int col = 0; col < 3; col++) {
            *Kernel_data = kernel[row][col];
        }
    }
}

void delay_ns(int ns) {
    for (volatile int i = 0; i < ns ; i++) {
        // No operation, chỉ để tạo trễ
    }
}

void write_matrix(const int matrix[9][9]) {
    for (int row = 0; row < 9; row++) {
        for (int col = 0; col < 9; col++) {
            *Matrix_data = matrix[row][col];
        }
    }
    delay_ns(96); // đợi ghi vào buff

}



int convert_data(int raw_data) {
    // Lấy giá trị dữ liệu (24 bit)
    int sign_bit = (raw_data >> 23) & 0x1; // Bit dấu nằm ở vị trí 23
    int data;

    if (sign_bit) {
        // Nếu là số âm: đảo bit và cộng 1
        data = ~raw_data & 0xFFFFFF ; // Đảo bit trên 24 bit
        data = data + 1;
        data = -data;                // Chuyển sang số âm
    } else {
        // Nếu là số dương: giữ nguyên
        data = raw_data & 0xFFFFFF; // Chỉ lấy 24 bit dưới
    }

    return data;
}

void read_results() {
    for (int i = 0; i < 25; i++) {
    	 //usleep(50000000);
    	 for (int j = 0; j < 1000000; j++){

    	 }
        // Đọc kết quả từ thanh ghi
        int result = IORD(CONVOLUTION_0_BASE,i);
        printf("Result %d(decimal): %d\n", i, result);
        // Tách dòng, cột và dữ liệu
        int row = (result >> 0) & 0xF;   // 4 bit đầu: dòng
        IOWR(HEX_4_BASE, 0, row);
        int col = (result >> 4) & 0xF;     // 4 bit tiếp theo: cột
        IOWR(HEX_5_BASE, 0, col);

        int hex0 = (result >> 8) & 0xF;    // 4 bit đầu
        int hex1 = (result >> 12) & 0xF;    // 4 bit tiếp theo
        int hex2 = (result >> 16) & 0xF;    // 4 bit tiếp theo
        int hex3 = (result >> 20) & 0xF;   // 4 bit tiếp theo

            // Hiển thị giá trị kết quả lên 4 LED HEX
        IOWR(HEX_0_BASE, 0, hex0); // HEX0 hiển thị 4 bit đầu
        IOWR(HEX_1_BASE, 0, hex1); // HEX1 hiển thị 4 bit tiếp theo
        IOWR(HEX_2_BASE, 0, hex2); // HEX2 hiển thị 4 bit tiếp theo
        IOWR(HEX_3_BASE, 0, hex3); // HEX3 hiển thị 4 bit tiếp theo

        int raw_data = (result >> 8) & 0xFFFFFF;     // 24 bit: dữ liệu thô

        // Chuyển đổi dữ liệu thô thành giá trị có dấu
        int data = convert_data(raw_data);

        // Lưu dữ liệu vào ma trận kết quả

            result_matrix[row][col] = data;

    }
}




//void display_result(int result) {
//    // Tách giá trị 32-bit thành 4 phần 8-bit để hiển thị dưới dạng hexa
//    int hex0 = (result >> 0) & 0xF;    // 4 bit đầu
//    int hex1 = (result >> 4) & 0xF;    // 4 bit tiếp theo
//    int hex2 = (result >> 8) & 0xF;    // 4 bit tiếp theo
//    int hex3 = (result >> 12) & 0xF;   // 4 bit tiếp theo
//
//    // Hiển thị giá trị kết quả lên 4 LED HEX
//    IOWR(HEX_0_BASE, 0, hex0); // HEX0 hiển thị 4 bit đầu
//    IOWR(HEX_0_BASE, 1, hex1); // HEX1 hiển thị 4 bit tiếp theo
//    IOWR(HEX_0_BASE, 2, hex2); // HEX2 hiển thị 4 bit tiếp theo
//    IOWR(HEX_0_BASE, 3, hex3); // HEX3 hiển thị 4 bit tiếp theo
//}

int main() {
    // Đọc giá trị từ switch (SW[1:0] để chọn kernel)
    //int selected_kernel = 0;        // Chọn kernel dựa vào switch
    // Chọn kernel và ghi vào thanh ghi kernel
    //select_kernel(selected_kernel);
    for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                *Kernel_data = kernel_1[row][col];
            }
        }
    // Matrix ví dụ 9x9
    const int matrix[5][5] = {
        {25, 12, 41, 33, 8},
        {74, 28, 1,  50, 45},
        {21, 53, 73, 9,  7},
        {60, 18, 58, 71, 47},
        {4,  20, 43, 70, 32}
    };


    // Ghi matrix vào thanh ghi matrix
    write_matrix(matrix);
        read_results();

        // Hiển thị kết quả ma trận
        printf("Kết quả ma trận 4x4:\n");
           for (int row = 0; row < 4; row++) {
               for (int col = 0; col < 4; col++) {
                   printf("%5d ", result_matrix[row][col]); // Hiển thị dữ liệu
               }
               printf("\n");
           }


    return 0;
}





